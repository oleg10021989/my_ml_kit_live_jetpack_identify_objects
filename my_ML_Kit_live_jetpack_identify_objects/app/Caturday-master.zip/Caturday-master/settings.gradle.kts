rootProject.buildFileName = "build.gradle.kts"
rootProject.name = "Caturday"
include(":app")

//include(":buildsrc")
//includeBuild(":buildSrc")
