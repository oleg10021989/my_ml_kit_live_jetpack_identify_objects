package pudans.caturday.model

data class PreviewImage(
	val id: String? = null,
	val url: String? = null
)
