package pudans.caturday.state

data class ProfileVideoItemState(
	val id: String,
	val url: String
)
