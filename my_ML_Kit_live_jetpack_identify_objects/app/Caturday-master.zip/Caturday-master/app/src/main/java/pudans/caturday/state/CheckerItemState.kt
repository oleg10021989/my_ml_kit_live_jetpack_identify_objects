package pudans.caturday.state

data class CheckerItemState(
	val name: String,
	val value: String,
	val isAccent: Boolean
)
