package pudans.caturday.di

import android.content.Context
import androidx.datastore.core.DataStore
import com.google.android.datatransport.runtime.dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent

//@Module
//@InstallIn(SingletonComponent::class)
object DataStoreModule {

//	@Provides
//	fun provideDataStore(@ApplicationContext context: Context): DataStore<Array<String>> = context.createDataStore("settings")
//
//	val Context.dataStore: DataStore<Array<String>> by preferencesDataStore(name = "settings")

}