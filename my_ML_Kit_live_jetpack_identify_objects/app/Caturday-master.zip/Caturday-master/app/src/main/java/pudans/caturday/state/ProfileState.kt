package pudans.caturday.state

data class ProfileState(
	val title: String,
	val avatarUrl: String,
	val nick: String
)
